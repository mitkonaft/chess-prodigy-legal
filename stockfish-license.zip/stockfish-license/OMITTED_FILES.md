# Files omitted from this lightweight source archive

Neural-network binaries and files larger than 10 MiB are excluded for GitHub web upload. The original local files have not been deleted.

| Relative path | Bytes | SHA-256 |
| --- | ---: | --- |
| `Networks/nn-1a298aa575a0.nnue` | 98,511,183 | `1a298aa575a085434d29027978dc36867fe9c5bcea9376654b7a8eba1e52dfc2` |

## Restore the evaluation network

For this snapshot, copy `Resources/Engines/nn-1a298aa575a0.nnue` from the original ChessCheater workspace into `stockfish-license/Networks/nn-1a298aa575a0.nnue` after extraction. Alternatively, request the exact matching file from the developer at ak.onfire@mail.ru. Verify its SHA-256 against the table above. The engine requires the network to perform evaluation; this source-only archive is not a complete runnable app package.

The official upstream Makefile includes network download support; verify any obtained file against the exact checksum above. Network redistribution notices and attribution are described in `Stockfish/upstream/README.md`.

GPLv3 text and source notices are preserved. This source-only ZIP does not itself certify fulfillment of all corresponding-source obligations for a distributed engine or linked application.
