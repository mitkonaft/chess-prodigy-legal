// swift-tools-version:6.0
// Stockfish-only extraction of the app build configuration. GPL-3.0-or-later.
import Foundation
import PackageDescription
let root = URL(fileURLWithPath: #filePath).deletingLastPathComponent().path
let package = Package(name: "ChessProdigyStockfishSource",
    platforms: [.iOS("26.0"), .macOS("15.0")],
    products: [.library(name: "Stockfish", targets: ["Stockfish"])],
    targets: [.target(name: "Stockfish", path: "Stockfish",
        exclude: ["upstream/src/main.cpp", "upstream/src/universal", "upstream/src/Makefile", "upstream/src/incbin/UNLICENCE"],
        sources: ["upstream/src"], publicHeadersPath: "include",
        cxxSettings: [.headerSearchPath("upstream/src"), .define("NDEBUG"), .define("NNUE_EMBEDDING_OFF"),
            .unsafeFlags(["-O3", "-Xarch_arm64", "-mcpu=apple-a13", "-w", "-include", "\(root)/Stockfish/StockfishConfig.h"])])],
    cxxLanguageStandard: .cxx20)
