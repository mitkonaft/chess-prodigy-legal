# Stockfish engine source — Chess Prodigy

Snapshot: October 18, 2026. The included source identifies itself as Stockfish 19. No upstream commit ID was retained in the local vendor directory; this package preserves that actual directory rather than substituting a different upstream download.

## Contents and licensing

- `Stockfish/upstream/`: full vendored engine tree, AUTHORS, upstream build scripts and GPLv3 `Copying.txt`.
- `LICENSE.txt`: full GNU GPLv3 text. Engine source notices permit GPLv3 or later.
- `Stockfish/StockfishConfig.h`: app configuration force-included in engine and bridge translation units.
- `EngineBridge/`: app Objective-C++ bridge and public header (including declarations for the separate Patricia bridge; Patricia implementation is not included here).
- `App-Package.swift.reference`: exact local app package build settings, including the separate Patricia target; an integration reference, not a standalone package.
- `Package.swift`: standalone Stockfish-only Swift package using the same source exclusions, defines, and optimization flags. It does not rebuild the entire app.
- Evaluation network binaries are excluded from this lightweight archive. See `OMITTED_FILES.md` for the exact filename, checksum, and restoration instructions. Upstream README describes network training-data attribution.
- `SHA256SUMS`: integrity manifest for the published snapshot.

Local integration files are distributed by mitkonaft games under GPLv3-or-later. Upstream notices remain intact. No claim of upstream endorsement is made.

## Build the engine library on Apple platforms

Install Xcode with a Swift 6 toolchain and C++20 support. From this directory:

```sh
shasum -a 256 -c SHA256SUMS
swift build -c release --target Stockfish
```

The standalone package retains the app’s deployment baselines (iOS 26 / macOS 15), `NDEBUG`, `NNUE_EMBEDDING_OFF`, force-included configuration, `-O3`, and ARM64 Apple A13/NEON flags. The app's package also passes `-w` to engine compilation; preserved here for matching settings. The package has no external dependency. These instructions have not been verified against a shipping archive.

For a conventional UCI executable, use the upstream Makefile and its documented platform architecture (run `make help` inside `Stockfish/upstream/src`). Restore the omitted network and make it available at the required path; the upstream Makefile may otherwise attempt to download it. See the preserved upstream README for its normal build procedure.

## iOS integration

The app excludes `main.cpp` and `src/universal` from its in-process target, disables NNUE embedding, and passes the absolute bundled network path as `EvalFile` via `StockfishBridge.initWithNetworkPath`. Compile `StockfishBridge.mm` as Objective-C++ with Foundation, dispatch, C++20, Stockfish headers, and the same force-included configuration/defines. The original package reference documents target dependencies; Patricia requires its separately licensed source. Complete combined-app rebuilding requires the remaining app source and dependencies and is outside this engine-only package.

For source availability and the developer’s source offer, see the repository root README. This package alone does not certify compliance of a linked app.

## Lightweight web-upload archive

This archive excludes neural-network binaries and files larger than 10 MiB. All engine source, headers, build files, and license notices are retained. `SHA256SUMS` covers this archive payload. The original local source directory remains intact. See `OMITTED_FILES.md` before rebuilding or distributing a corresponding binary.
