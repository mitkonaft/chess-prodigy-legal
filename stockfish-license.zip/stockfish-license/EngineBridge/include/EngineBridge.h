// The only header Swift sees. Stockfish and Patricia C++ never leak into Swift.
#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSInteger, CEScoreKind) {
    CEScoreKindCentipawns,
    CEScoreKindMate,        // scoreValue = plies to mate, signed, side-to-move point of view
    CEScoreKindTablebase,   // scoreValue = plies, signed
};

/// One `info` update of a search line. Scores are from the side to move.
@interface CEInfo : NSObject
@property (nonatomic) NSInteger multipv;
@property (nonatomic) NSInteger depth;
@property (nonatomic) NSInteger scoreValue;
@property (nonatomic) CEScoreKind scoreKind;
@property (nonatomic) uint64_t nodes;
@property (nonatomic) uint64_t nps;
/// Space-separated UCI moves.
@property (nonatomic, copy) NSString *pv;
@end

/// Stockfish 19 through its C++ `Engine` class: no UCI text, no stdin/stdout.
/// Callbacks arrive on Stockfish's search threads.
NS_SWIFT_SENDABLE
@interface StockfishBridge : NSObject
- (instancetype)initWithNetworkPath:(NSString *)path NS_DESIGNATED_INITIALIZER;
- (instancetype)init NS_UNAVAILABLE;
/// Same semantics as UCI `setoption name <name> value <value>`. Blocks until applied.
- (void)setOption:(NSString *)name value:(NSString *)value;
/// Stops any running search, then starts this one. `onBestMove` is called exactly once.
- (void)analyzeFEN:(NSString *)fen
             depth:(NSInteger)depth
       searchMoves:(nullable NSArray<NSString *> *)moves
            onInfo:(void (^ NS_SWIFT_SENDABLE)(CEInfo *info))onInfo
        onBestMove:(void (^ NS_SWIFT_SENDABLE)(NSString *bestMove))onBest;
- (void)stop;
@end

/// Patricia 5.1 running its own UCI loop on an 8 MB-stack thread, with in-memory I/O.
NS_SWIFT_SENDABLE
@interface PatriciaBridge : NSObject
@property (class, nonatomic, readonly) PatriciaBridge *shared;
/// Called on Patricia's threads, one call per output line.
@property (atomic, copy, nullable) void (^ NS_SWIFT_SENDABLE onLine)(NSString *line);
- (void)send:(NSString *)uciCommand;
@end

NS_ASSUME_NONNULL_END
