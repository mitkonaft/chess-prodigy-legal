#import "EngineBridge.h"

#include "PatriciaIO.h"

@implementation PatriciaBridge

+ (PatriciaBridge *)shared {
    static PatriciaBridge *shared;
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        shared = [[PatriciaBridge alloc] init];
        __weak PatriciaBridge *weakShared = shared;
        patricia_io::set_sink([weakShared](std::string line) {
            void (^callback)(NSString *) = weakShared.onLine;
            if (callback) callback([NSString stringWithUTF8String:line.c_str()] ?: @"");
        });
        patricia_io::start();
    });
    return shared;
}

- (void)send:(NSString *)uciCommand {
    patricia_io::send(uciCommand.UTF8String);
}

@end
