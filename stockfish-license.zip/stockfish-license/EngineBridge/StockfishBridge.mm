#import "EngineBridge.h"

#include <memory>
#include <sstream>
#include <string>
#include <type_traits>

#include "attacks.h"
#include "engine.h"
#include "misc.h"
#include "position.h"
#include "score.h"
#include "search.h"

using namespace Stockfish;

static NSString *NSStr(std::string_view s) {
    return [[NSString alloc] initWithBytes:s.data() length:s.size() encoding:NSUTF8StringEncoding] ?: @"";
}

@implementation CEInfo
@end

@implementation StockfishBridge {
    std::unique_ptr<Engine> _engine;
    dispatch_queue_t _control;   // serializes option changes, set_position, go and stop
}

+ (void)initialize {
    if (self == [StockfishBridge class]) {
        Attacks::init();         // what Stockfish's main() does before creating the engine
        Position::init();
    }
}

- (instancetype)initWithNetworkPath:(NSString *)path {
    if ((self = [super init])) {
        _control = dispatch_queue_create("app.chessprodigy.stockfish", DISPATCH_QUEUE_SERIAL);
        _engine = std::make_unique<Engine>(std::string(path.fileSystemRepresentation));
        // Every callback must be set: Stockfish calls them unconditionally.
        _engine->set_on_update_no_moves([](const Engine::InfoShort &) {});
        _engine->set_on_update_full([](const Engine::InfoFull &) {});
        _engine->set_on_iter([](const Engine::InfoIter &) {});
        _engine->set_on_start([] {});
        _engine->set_on_bestmove([](std::string_view, std::string_view) {});
        _engine->set_on_verify_network([](std::string_view message) {
            NSLog(@"[Stockfish] %@", NSStr(message));
        });
        [self setOption:@"EvalFile" value:path];
    }
    return self;
}

- (void)setOption:(NSString *)name value:(NSString *)value {
    std::string command = std::string("name ") + name.UTF8String + " value " + value.UTF8String;
    dispatch_sync(_control, ^{
        std::istringstream is(command);
        self->_engine->get_options().setoption(is);
    });
}

- (void)analyzeFEN:(NSString *)fen
             depth:(NSInteger)depth
       searchMoves:(NSArray<NSString *> *)moves
            onInfo:(void (^)(CEInfo *))onInfo
        onBestMove:(void (^)(NSString *))onBest {
    std::string fenString = fen.UTF8String;
    NSArray<NSString *> *searchMoves = [moves copy];
    dispatch_async(_control, ^{
        Engine &engine = *self->_engine;
        engine.stop();
        engine.wait_for_search_finished();

        engine.set_on_update_full([onInfo](const Engine::InfoFull &i) {
            CEInfo *info = [CEInfo new];
            info.multipv = NSInteger(i.multiPV);
            info.depth = i.depth;
            info.nodes = i.nodes;
            info.nps = i.nps;
            info.pv = NSStr(i.pv);
            i.score.visit([&](auto &&s) {
                using T = std::decay_t<decltype(s)>;
                if constexpr (std::is_same_v<T, Score::Mate>) {
                    info.scoreKind = CEScoreKindMate;
                    info.scoreValue = s.plies;
                } else if constexpr (std::is_same_v<T, Score::Tablebase>) {
                    info.scoreKind = CEScoreKindTablebase;
                    info.scoreValue = s.plies;
                } else {
                    info.scoreKind = CEScoreKindCentipawns;
                    info.scoreValue = s.value;
                }
            });
            onInfo(info);
        });
        engine.set_on_bestmove([onBest](std::string_view best, std::string_view) { onBest(NSStr(best)); });

        if (engine.set_position(fenString, {})) {     // PositionSetError
            onBest(@"(none)");
            return;
        }
        Search::LimitsType limits;
        limits.startTime = now();
        limits.depth = int(depth);
        limits.movetime = 8000; // Bound foreground battery use even in difficult positions.
        for (NSString *m in searchMoves) limits.searchmoves.emplace_back(m.UTF8String);
        engine.go(limits);    // returns at once; the search runs on Stockfish's own threads
    });
}

- (void)stop {
    dispatch_async(_control, ^{ self->_engine->stop(); });
}

@end
