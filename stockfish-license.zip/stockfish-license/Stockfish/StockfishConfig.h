// Force-included into every Stockfish and bridge translation unit. These defines change
// struct layouts, so the engine and the bridge must always agree on them.
#pragma once
#define IS_64BIT 1
#if defined(__aarch64__)
  #define USE_POPCNT 1
  #define USE_NEON 8
  #define USE_NEON_DOTPROD 1
#endif
